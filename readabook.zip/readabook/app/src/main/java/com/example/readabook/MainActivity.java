package com.example.readabook;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);
        TextView textView = findViewById(R.id.textViewTitle);

        String[] itme = getResources().getStringArray(R.array.index);

        Typeface typeface = Typeface.createFromAsset(getAssets(),"Suki Yaki - Personal Use.otf");
        textView.setTypeface(typeface);

        ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this,R.layout.row_itme,R.id.textitme,itme);

        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this,webhtml.class);
                intent.putExtra("page",position);
                startActivity(intent);

            }
        });
    }

    public void img_share(View view) {

        String txtshare ="read a book app";
        String sharelink = "https://play.google.com/store/apps/details?id=com.example.readabook";

        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,txtshare +"\n" + sharelink);
        startActivity(share);
    }

    public void img_close(View view) {finish();}



    public void img_email(View view) {
    }

    public void img_morapp(View view) {
    }
}